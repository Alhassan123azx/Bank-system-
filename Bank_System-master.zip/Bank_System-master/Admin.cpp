#include "Admin.h"
//Admin* Admin::instance = NULL;;	// Initialize static member outside the class