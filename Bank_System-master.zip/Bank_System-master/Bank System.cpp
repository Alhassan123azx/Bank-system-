#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <limits>
#include <conio.h>
#include<fstream>

#include "Person.h"
#include "Client.h"
#include "Employee.h"
#include "Admin.h"
#include "ClientManger.h"
#include "EmployeeManager.h"
#include "AdminManager.h"
#include "Screens.h"
using namespace std;

int main()
{
	/*ClientManger c;
	Client* aa = new Client;
	c.updatePassword(aa);*/

	//Screens::runApp();

	return 0;
}
